package com.example.roommates

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
